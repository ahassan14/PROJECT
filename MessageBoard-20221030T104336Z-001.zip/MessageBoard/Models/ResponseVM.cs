﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MessageBoard.Models
{
    public class ResponseVM
    {
        public bool IsSuccess { get; set; }

        public string  Message { get; set; }

        public int Role { get; set; }
        
    }
}