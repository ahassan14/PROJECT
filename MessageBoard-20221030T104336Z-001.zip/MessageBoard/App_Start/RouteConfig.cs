﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace MessageBoard
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
       name: "Contact-List",
       url: "Contact-List",
       defaults: new { controller = "Admin", action = "ContactList", id = UrlParameter.Optional }

   );

            routes.MapRoute(
         name: "Contact-Us",
         url: "Contact-Us",
         defaults: new { controller = "Home", action = "Contact", id = UrlParameter.Optional }

     );

            routes.MapRoute(
         name: "Admin-Blog-View",
         url: "Admin-Blog-View",
         defaults: new { controller = "Admin", action = "AdminBlogList", id = UrlParameter.Optional }

     );


            routes.MapRoute(
            name: "Blog-View",
            url: "Blog-View",
            defaults: new { controller = "Blog", action = "BlogList", id = UrlParameter.Optional }

        );

            routes.MapRoute(
              name: "Blog-Post",
              url: "Blog-Post",
              defaults: new { controller = "Blog", action = "Blog", id = UrlParameter.Optional }

          );
            routes.MapRoute(
              name: "Sign-Up",
              url: "Sign-Up",
              defaults: new { controller = "Home", action = "SignUp", id = UrlParameter.Optional }

          );
            routes.MapRoute(
               name: "Login",
               url: "Login",
               defaults: new { controller = "Home", action = "Login", id = UrlParameter.Optional }
           );
            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}
