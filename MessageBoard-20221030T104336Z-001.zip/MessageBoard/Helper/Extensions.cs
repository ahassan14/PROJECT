﻿using MessageBoard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MessageBoard.Controllers;
using MessageBoard.Database;

namespace MessageBoard.Helper
{
    public static class Extensions
    {

         public static UserVM _Currentuser;
        public static UserVM CurrentUser
        {
            get
            {
                _Currentuser = GetUser();
                return _Currentuser;
            }
        }

        public static UserVM GetUser()
        {
            try
            {

                int sessionId = Globalvariable.Adminlogin;

                //  string sessionId = HttpContext.Current.Session["AdminLogin"].ToString();// Session["AdminLogin"].ToString();

                //string sessionId = Session["AdminLogin"].ToString();

                UserVM model = new UserVM();
                messageboardEntities dbContext = new messageboardEntities();
                if (sessionId > 0)
                {
                    int userid = Convert.ToInt32(sessionId);
                    var entity = dbContext.Users.Find(userid);
                    if (entity != null)
                    {
                        model.ID = entity.ID;
                        model.FirstName = entity.FirstName;
                        model.LastName = entity.LastName;
                        model.Email = entity.Email;
                        model.ImageUrl = entity.ImageUrl;
                        model.UserRollId = entity.UserRollId;
                    }
                }



                return model;
            }
            catch (Exception ex)
            {
                HttpContext.Current.Session.RemoveAll();

                throw ex;
            }
        }
    }
}