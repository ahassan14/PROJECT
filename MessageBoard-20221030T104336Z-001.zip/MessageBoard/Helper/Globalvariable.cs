﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MessageBoard.Helper
{
    public class Globalvariable
    {
        public static int Adminlogin = 0;
    }
}