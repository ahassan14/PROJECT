﻿using MessageBoard.Database;
using MessageBoard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MessageBoard.Controllers
{
    public class BlogController : BaseController
    {
        messageboardEntities dbContext = new messageboardEntities();
        // GET: Blog
        public ActionResult Blog()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult Blog(BlogVM model)
        {
            try
            {
                ViewBag.result = "Insert Valid  Details";
                var entity = new BlogPost();
                if (ModelState.IsValid)
                {
                    entity.Title = model.Title;
                    entity.Message = model.Message;
                    entity.CreatedBy = GetUserId();
                    entity.CreatedDate = DateTime.Now;
                    entity.IsApprove = false;
                    entity.IsActive = true;
                    entity.IsDeleted = false;
                    entity.UpdatedDate = DateTime.Now;
                    dbContext.BlogPosts.Add(entity);
                    dbContext.SaveChanges();
                    ViewBag.result = "Data Submit Successfully";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return View();
        }



        public ActionResult BlogList()
        {
            try
            {
                var model = dbContext.BlogPosts.Where(x => x.IsDeleted == false).OrderByDescending(x=>x.ID)
                    .Select(x => new BlogVM()
                {
                    Title = x.Title,
                    Message = x.Message,
                    CreatedDate = x.CreatedDate,
                    CreatedBy = x.CreatedBy,
                    IsActive = x.IsActive,
                    IsApprove = x.IsApprove,
                    Users = new UserVM()
                    {
                        FirstName = x.User.FirstName,
                        LastName = x.User.LastName,
                        ImageUrl = x.User.ImageUrl,
                        Email = x.User.Email,
                    }

                }).ToList();  

                return View(model);

            }
            catch (Exception ex)
            {
                throw ex;
            }
           
        }


       
    }
}