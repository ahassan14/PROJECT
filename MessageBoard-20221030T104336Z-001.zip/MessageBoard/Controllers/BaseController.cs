﻿using MessageBoard.Database;
using MessageBoard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MessageBoard.Helper;

namespace MessageBoard.Controllers
{
    public class BaseController : Controller
    {
        messageboardEntities dbContext = new messageboardEntities();
        UserVM user = new UserVM();
        public int _userId;


        //public UserVM cussertuser()
        //{

        //    var user = Extensions.CurrentUser;
        //    if (user == null)
        //    {
        //        Session.RemoveAll();
        //        RedirectToAction("Index", "Home");
        //    }

        //    return user;
        //}

        public int GetUserId()
        {
            int userId = 0;
            int sessionId = Globalvariable.Adminlogin;
            if (sessionId > 0)
            {
                userId = Convert.ToInt32(sessionId);
                var entity = dbContext.Users.Find(userId);
            }
            else
            {
                RedirectToAction("Index", "Home");
            }
            _userId = userId;
            return userId;
        }

    }
}