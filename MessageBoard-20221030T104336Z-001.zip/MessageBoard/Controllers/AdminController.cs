﻿using MessageBoard.Database;
using MessageBoard.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MessageBoard.Helper;

namespace MessageBoard.Controllers
{
    public class AdminController : BaseController
    {
        messageboardEntities dbContext = new messageboardEntities();

        public ActionResult AdminBlogList()
        {
            
            try
            {
                var model = dbContext.BlogPosts.Where(x => x.IsDeleted == false).OrderByDescending(x=>x.ID)
                    .Select(x => new BlogVM()
                {
                    ID = x.ID,
                    Title = x.Title,
                    Message = x.Message,
                    CreatedDate = x.CreatedDate,
                    CreatedBy = x.CreatedBy,
                    IsActive = x.IsActive,
                    IsApprove = x.IsApprove,
                    Users = new UserVM()
                    {
                        FirstName = x.User.FirstName,
                        LastName = x.User.LastName,
                        ImageUrl = x.User.ImageUrl,
                        Email = x.User.Email,
                    }

                }).ToList();

                return View(model);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public ActionResult ApproveBlog(int id)
        {
            int res = 0;
            if(id>0)
            {
                var model = dbContext.BlogPosts.Find(id);
                if (model != null)
                {
                    model.IsApprove = true;
                    model.IsActive = true ;
                    model.UpdatedDate = DateTime.Now;
                    dbContext.SaveChanges();
                    res = 1;
                } 
            }

            return Json(res);

        }
        public ActionResult RejectBlog(int id)
        {
            int res = 0;
            if (id > 0)
            {
                var model = dbContext.BlogPosts.Find(id);
                if (model != null)
                {
                    model.IsApprove = false;
                    model.IsActive = false;
                    model.UpdatedDate = DateTime.Now;
                    dbContext.SaveChanges();
                    res = 1;
                }
            }

            return Json(res);

        }

        public ActionResult ContactList()
        {
            try
            {
                var model = dbContext.ContactUs.Where(x => x.IsDelete == false).OrderByDescending(x => x.Id)
                    .Select(x => new ContactVM()
                {
                    Id = x.Id,
                    Name = x.Name,
                    Message = x.Message,
                    Subject  = x.Subject,
                    Email = x.Email,
                    ContactNo = x.ContactNo,
                    CreatedDate = x.CreatedDate,
                    

                }).ToList();

                return View(model);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        public ActionResult DeleteContact(int id)
        {
            int res = 0;
            if (id > 0)
            {
                var model = dbContext.ContactUs.Find(id);
                if (model != null)
                {
                  
                    model.IsDelete = true;
                    model.UpdatedDate = DateTime.Now;
                    dbContext.SaveChanges();
                    res = 1;
                }
            }

            return Json(res);

        }
    }
}