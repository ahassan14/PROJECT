﻿using MessageBoard.Database;
using MessageBoard.Helper;
using MessageBoard.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MessageBoard.Controllers
{
    public class HomeController : Controller
    {
        messageboardEntities dbContext = new messageboardEntities();
        ResponseVM response = new ResponseVM();
        public ActionResult Index()
        {
            return View();

        }
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(LogInVM model)
        {
            ViewBag.result = "Insert Valid Login Details";
            if (ModelState.IsValid)
            {
                var entity = dbContext.Users.Where(x => x.Email == model.Email && x.Password == model.Password
                && x.IsActive == true && x.IsDeleted == false).FirstOrDefault();
                if (entity != null)
                {
                    int loginid = entity.ID;
                    Session["AdminLogin"] = loginid;
                    Globalvariable.Adminlogin = loginid;

                    if (entity.UserRollId == 1)
                    {
                        ViewBag.roll = "Admin";
                    }
                    else
                    {
                        ViewBag.roll = "User";

                    }
                    ViewBag.result = "login successfully";
                    //  return RedirectToAction("Index", "HomeAdmin", new { @area = "Admin" });
                }

            }

            return View();
        }

        public ActionResult SignUp()
        {
            return View();
        }
        [HttpPost]
        public ActionResult SignUp(UserVM model, HttpPostedFileBase file)
        {
            //~/ Images / Upload / User / login - register.jpg

            ViewBag.result = "Enter Valid Details";
            if (ModelState.IsValid)
            {
                var entity = dbContext.Users.Where(x => x.Email == model.Email).FirstOrDefault();
                if (entity == null)
                {
                    entity = new User();
                    entity.FirstName = model.FirstName;
                    entity.LastName = model.LastName;
                    entity.Email = model.Email;
                    entity.Password = model.Password;
                    entity.IsActive = true;
                    entity.IsDeleted = false;
                    entity.CreatedDate = DateTime.Now;
                    entity.UpdatedDate = DateTime.Now;
                    entity.UserRollId = 2;


                    if (model.PostedFile != null)
                    {
                        string fileName = Path.GetFileName(model.PostedFile.FileName);
                        if (model.PostedFile.ContentLength > 0)
                        {
                            Random objran = new Random();
                            string ranno1 = objran.Next(1000000000).ToString("D5");
                            string myfilename3 = ranno1 + "-k-" + fileName;

                            model.ImageUrl = "Images/Upload/User/" + myfilename3;

                            //upload 720px * 720px
                            model.PostedFile.SaveAs(Server.MapPath("~/Images/Upload/User/") + myfilename3);

                            entity.ImageUrl = model.ImageUrl;
                        }
                    }



                    dbContext.Users.Add(entity);
                    dbContext.SaveChanges();

                    ViewBag.result = "Data Submit Successfully";

                }
                else
                {
                    ViewBag.result = "Email Already Taken!!";
                }
            }
            return View();
        }

        public ActionResult LogOut()
        {
            Session.RemoveAll();
            return RedirectToAction("Index", "Home");
        }

        public ActionResult Contact()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Contact(ContactVM model)
        {
            ViewBag.result = "Insert Valid Login Details";
            if (ModelState.IsValid)
            {
                var entity = new ContactU();
                entity.Name = model.Name;
                entity.ContactNo = model.ContactNo;
                entity.Email = model.Email;
                entity.Subject = model.Subject;
                entity.Message = model.Subject;
                entity.IsActive = true;
                entity.IsDelete = false;
                entity.CreatedDate = DateTime.Now;
                entity.UpdatedDate = DateTime.Now;

                dbContext.ContactUs.Add(entity);
                dbContext.SaveChanges();
                ViewBag.result = "Data Submit successfully";

            }
            return View();
        }
    }
}